package model;

public interface IPersoana {
    public String getSex();

    public int getVarsta();

    public boolean checkCNP();
}
