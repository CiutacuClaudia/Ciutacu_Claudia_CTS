package test;

public class ExceptieCNPNull extends RuntimeException {
}
