package test;

public class ExceptieNenascut extends RuntimeException {

}
